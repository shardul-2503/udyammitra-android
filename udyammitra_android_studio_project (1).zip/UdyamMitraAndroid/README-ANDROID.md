# UdyamMitra Android wrapper

This is an Android Studio project that wraps the UdyamMitra web app in an Android WebView so it can be built into an APK.

## Build an APK
1. Install Android Studio on a computer.
2. Install Android SDK Platform 35 and a compatible Android Gradle plugin/Gradle version when prompted.
3. Open this folder (`UdyamMitraAndroid`) in Android Studio.
4. Let Gradle sync finish.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone, allow installation from that source if prompted, and install it.

## Notes and limitations
- Package ID: `in.udyammitra.app`; version 1.0.0.
- Internet permission is enabled for online data requests.
- This is a prototype wrapper, not a production-ready secure account system. User accounts and business records remain local to the WebView/browser storage and do not sync between devices.
- Browser restrictions may prevent the local `file://` app from calling external market APIs directly. For reliable live market data, host the website over HTTPS and proxy API requests through a server that protects the API key.
- Do not enter sensitive personal, customer or banking information in this prototype.

## Optional: build APK automatically with GitHub Actions
This project includes `.github/workflows/build-apk.yml`. Upload the project contents to a GitHub repository, then open **Actions > Build UdyamMitra APK > Run workflow**. When the workflow completes, download the `udyammitra-debug-apk` artifact and extract `app-debug.apk`.
